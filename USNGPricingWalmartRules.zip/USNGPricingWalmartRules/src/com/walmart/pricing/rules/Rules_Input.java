package com.walmart.pricing.rules;

/**
 * 
 * @author Mahak
 * @version 1.0
 *
 */

public class Rules_Input {

	private double proposedRetail;

	private double currentCost;

	public double getProposedRetail() {
		return proposedRetail;
	}

	public void setProposedRetail(double proposedRetail) {
		this.proposedRetail = proposedRetail;
	}

	public double getCurrentCost() {
		return currentCost;
	}

	public void setCurrentCost(double currentCost) {
		this.currentCost = currentCost;
	}

}

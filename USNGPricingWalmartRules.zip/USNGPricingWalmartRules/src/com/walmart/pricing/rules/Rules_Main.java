package com.walmart.pricing.rules;

/**
 * 
 * @author Mahak
 * @version 1.0 <h1>Main Class for Rules</h1>
 *
 */

public class Rules_Main {

	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		Rules_Integration rulesCheck = new Rules_Integration();
		long startTime, endTime;

		// Compliance Rule Output
		startTime = System.nanoTime();
		boolean complianceRuleFlag = rulesCheck.complianceRule(4.89, 4.9);
		endTime = System.nanoTime();

		System.out.println("Time Taken by Compliance Rule: "
				+ (endTime - startTime) + " nano seconds");

		if (complianceRuleFlag)
			System.out.println("Compliance Rule Passed");
		else
			System.out.println("Compliance Rule Failed");

		System.out
				.println("****************************************************");
		
		startTime = 0;
		endTime = 0;
		
		
		// Price Point Ending 1,5,9 rule check
		startTime = System.nanoTime();
		boolean pricePointEnding159RuleFlag = rulesCheck
				.pricePointEnding159(5.9);
		endTime = System.nanoTime();

		System.out.println("Time Taken by PricePointEnding 1,5,9 Rule: "
				+ (endTime - startTime) + " nano seconds");

		if (pricePointEnding159RuleFlag)
			System.out.println("Price Point Ending 1,5,9 Rule Failed");
		else
			System.out.println("Price Point Ending 1,5,9 Rule Passed");
	}

}

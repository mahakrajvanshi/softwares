package com.walmart.pricing.rules;

/**
 * 
 * @author Mahak
 * @version 1.0
 *
 */

public interface Rules_Declarations {
	
	//Compliance Rule
	public boolean complianceRule(double proposedRetail, double currentCost);
	
	//Price Point Ending 1,5,9 Rule
	public boolean pricePointEnding159(double proposedRetail);

}

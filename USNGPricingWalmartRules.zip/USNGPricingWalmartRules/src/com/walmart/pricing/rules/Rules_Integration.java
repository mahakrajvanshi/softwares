package com.walmart.pricing.rules;

/**
 * 
 * @author Mahak
 * @version 1.0
 *
 */

public class Rules_Integration implements Rules_Declarations {
	
	//Compliance Rule Check
	/**
	 * 
	 * @param proposedRetail
	 * @param currentCost
	 */
	@Override
	public boolean complianceRule(double proposedRetail, double currentCost) {
		
		if(proposedRetail > currentCost)
			return true;
		
		return false;
	}
	
	//Price Point Ending 1,5,9 rule check
	/**
	 * 
	 * @param proposedRetail
	 */
	@Override
	public boolean pricePointEnding159(double proposedRetail) {
		
		String propRetail = proposedRetail + "";
		char priceCheck159 = propRetail.charAt(propRetail.length() - 1);
		
		if(priceCheck159 == '1' || priceCheck159 == '5' || priceCheck159 == '9')
			return true;
		
		return false;
	}
	
	

}
